/*
 * simulink_experiment_eval_type1_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "simulink_experiment_eval_type1".
 *
 * Model version              : 1.9
 * Simulink Coder version : 8.11 (R2016b) 25-Aug-2016
 * C source code generated on : Thu May 05 12:52:22 2022
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_simulink_experiment_eval_type1_types_h_
#define RTW_HEADER_simulink_experiment_eval_type1_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#ifndef struct_tag_s6UqFZyLY2QsfiWKX3iHODC
#define struct_tag_s6UqFZyLY2QsfiWKX3iHODC

struct tag_s6UqFZyLY2QsfiWKX3iHODC
{
  int32_T isInitialized;
  real_T t_prev;
  real_T p_prev;
  real_T v_prev;
  real_T theta_prev;
  real_T theta_dot_prev;
  real_T dt;
  real_T integrated_position_error;
  real_T integrated_theta_error;
  real_T wave_pattern;
  real_T A;
  real_T omega;
};

#endif                                 /*struct_tag_s6UqFZyLY2QsfiWKX3iHODC*/

#ifndef typedef_studentControllerInterface_si_T
#define typedef_studentControllerInterface_si_T

typedef struct tag_s6UqFZyLY2QsfiWKX3iHODC studentControllerInterface_si_T;

#endif                                 /*typedef_studentControllerInterface_si_T*/

#ifndef typedef_struct_T_simulink_experiment__T
#define typedef_struct_T_simulink_experiment__T

typedef struct {
  real_T f0[2];
  real_T f1[2];
  real_T f2[2];
} struct_T_simulink_experiment__T;

#endif                                 /*typedef_struct_T_simulink_experiment__T*/

/* Parameters (auto storage) */
typedef struct P_simulink_experiment_eval_ty_T_ P_simulink_experiment_eval_ty_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_simulink_experiment_e_T RT_MODEL_simulink_experiment__T;

#endif                                 /* RTW_HEADER_simulink_experiment_eval_type1_types_h_ */
