clear all;
addpath(genpath('.'));